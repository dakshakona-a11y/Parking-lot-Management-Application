package com.parkinglot.domain;

public enum VehicleType {
    SMALL,
    LARGE,
    OVERSIZE
}